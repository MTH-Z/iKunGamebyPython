import json, time, tkinter

import pygame
from pygame.mixer import Sound


def play_bgm():
    try:
        bgm = Sound('Data/audio/bgm.mp3')
        bgm.set_volume(0.5)
        bgm.play(loops=-1, maxtime=0, fade_ms=0)
    except:
        tkinter.messagebox.showerror(
            "Error", "Not found audio output device."
            )
        pygame.quit()

def classic_click():
    click = Sound('Data/audio/classic_click.wav')
    click.play(loops=0, maxtime=0, fade_ms=0)

def defeat_classic(score):
    defeat = Sound('Data/audio/defeat.wav')
    defeat.play(loops=0, maxtime=0, fade_ms=0)
    print(f"\rDEFEAT Score:{score}")
    time.sleep(3.5)
    pygame.quit()

def defeat_endless(highest):
    defeat = Sound('Data/audio/defeat.wav')
    defeat.play(loops=0, maxtime=0, fade_ms=0)
    print(f"\nDEFEAT")
    time.sleep(3.5)
    with open('Data/scores.json', encoding = 'utf-8') as scores:
            s = json.load(scores)
    s["best_score"]["endless"]["score"] = 0
    s["best_score"]["endless"]["time"] = 0
    s["best_score"]["endless"]["highest"] = highest
    with open('Data/scores.json', mode='w', encoding = 'utf-8') as scores:
        json.dump(s, scores)
    pygame.quit()

def victory(game_time, difficulty):
    victory = Sound('Data/audio/victory.wav')
    victory.play(loops=0, maxtime=0, fade_ms=0)
    difficulty = difficulty.title()
    game_time = round(game_time, 2)
    print(f"\rVICTORY Difficulty:{difficulty} Time:{game_time}s")
    with open('Data/scores.json', encoding = 'utf-8') as scores:
        s = json.load(scores)
    if s["best_score"]["classic"][difficulty] < game_time:
        s["best_score"]["classic"][difficulty] = game_time
        with open('Data/scores.json', mode='w', encoding = 'utf-8') as scores:
            json.dump(s, scores)
    best_score = s["best_score"]["classic"][difficulty]
    print(f"BestScore:{best_score}s ({difficulty})")
    time.sleep(1.5)
    pygame.quit()

def clear_score_list():
    with open('Data/scores.json', encoding = 'utf-8') as scores:
        s = json.load(scores)
    s["best_score"]["classic"]["Easy"] = 0
    s["best_score"]["classic"]["Normal"] = 0
    s["best_score"]["classic"]["Hard"] = 0
    s["best_score"]["classic"]["Insane"] = 0
    s["best_score"]["endless"]["score"] = 0
    s["best_score"]["endless"]["time"] = 0
    s["best_score"]["endless"]["highest"] = 0
    with open('Data/scores.json', mode='w', encoding = 'utf-8') as scores:
        json.dump(s, scores)
    print('--The highest score has been reset--.')

def score_board_classic(score, total_score):
    print('\r', f"{score}/{total_score}", end='', flush=True)

def score_board_endless(score, game_time):
    print('\r', f"{score} {round(game_time, 2)}s", end='', flush=True)

def timer():
    pass

def about():
    window = tkinter.Tk()
    window.title("About")
    window.geometry("350x200")
    lbl = tkinter.Label(window, text="Version: v1.2")
    lbl.pack(anchor="nw")
    lbl = tkinter.Label(window, text="@Meteor2024 Copyright")
    lbl.pack(anchor="nw")
